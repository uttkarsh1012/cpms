<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['autoinit'] Whether or not to automatically initialize the database.
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/

$active_group = 'default';
$active_record = TRUE;


$db['default']['hostname'] = getenv("DATABASE_HOST");
$db['default']['username'] = getenv("DATABASE_USER");
$db['default']['password'] = getenv("DATABASE_PASS");
$db['default']['database'] = getenv("DATABASE_NAME");

	
$db['default']['dbdriver'] = 'mysqli';
$db['default']['dbprefix'] = '';
$db['default']['pconnect'] = TRUE;
$db['default']['db_debug'] = (ENVIRONMENT == 'production') ? FALSE : TRUE; // Changed by Jaeyun on Mar 8, 11 in order to handle calender occupancy errors.
$db['default']['cache_on'] = FALSE;
$db['default']['cachedir'] = '';
$db['default']['char_set'] = 'utf8';
$db['default']['dbcollat'] = 'utf8_general_ci';
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;




$db['roomsy_db']['hostname'] = getenv("DATABASE_HOST_ROOMSY");
$db['roomsy_db']['username'] = getenv("DATABASE_USER_ROOMSY");
$db['roomsy_db']['password'] = getenv("DATABASE_PASS_ROOMSY");
$db['roomsy_db']['database'] = getenv("DATABASE_NAME_ROOMSY");

	
$db['roomsy_db']['dbdriver'] = 'mysqli';
$db['roomsy_db']['dbprefix'] = '';
$db['roomsy_db']['pconnect'] = TRUE;
$db['roomsy_db']['db_debug'] = (ENVIRONMENT == 'production') ? FALSE : TRUE; // Changed by Jaeyun on Mar 8, 11 in order to handle calender occupancy errors.
$db['roomsy_db']['cache_on'] = FALSE;
$db['roomsy_db']['cachedir'] = '';
$db['roomsy_db']['char_set'] = 'utf8';
$db['roomsy_db']['dbcollat'] = 'utf8_general_ci';
$db['roomsy_db']['swap_pre'] = '';
$db['roomsy_db']['autoinit'] = TRUE;
$db['roomsy_db']['stricton'] = FALSE;


/* End of file database.php */
/* Location: ./application/config/database.php */
